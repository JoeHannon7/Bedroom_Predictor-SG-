
Author: Joseph Hannon (joehannon7@gmail.com)


INTRODUCTION
------------

This application is a regressio-based predictor for the number of bedrooms of a given property.
The following files have been included:

1. Prediction.cpp (C++ source file)
2. Prediction.exe (C++ executable file)
3. Roooms_Analysis.r (R script that performs correlation and linear regression)
4. Training.csv (the training dataset for the regression model)
5. Test.csv (the test data for the executable)

SYSTEM REQUIREMENTS
-------------------

This application is designed to operate on Windows 10 or higher for a 64-bit machine.


HOW TO USE
------------

The R script requires the training dataset to be included in the current working directory.

The regression model can be run by double clicking on the executable. This will automatically generate a csv file
called "prediction.csv" that will include the test data with an additional field for the predicted number of bedrooms.

A test dataset is already provided which may be altered as preferred.

