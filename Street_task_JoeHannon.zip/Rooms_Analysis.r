#use library 'tidyverse'
library(tidyverse)
#Read in training data
data<-read.csv("training.csv")
# Make correlation matrix to see relationships
cor(data[, unlist(lapply(data, is.numeric))]) 
# Perform a multiple linear regression for two variables
model <- lm(data$Bedrooms ~ data$Floor_Area + data$Rooms)
# Get model summary and confidence intervals
summary(model)
summary(model)$coefficient
confint(model)

