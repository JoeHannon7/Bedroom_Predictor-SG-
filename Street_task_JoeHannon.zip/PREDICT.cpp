#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <cctype>
#include <string>
#include <cstring>
#include <iostream>
#include <math.h>
using namespace std;


/*****  THIS IS A REGRESSION MODEL FOR PREDICTING THE NUMBER OF BEDROOMS FROM A DATASET CONTAINING INFORMATION ON A GIVEN PROPERTY ******/


/* Declare variables */

int n=0; int i=0; int j=0; int pos=0; int index=0;
int floor_area=0,num_rooms=0; string line, header; 


/* y = m1m2(x) +c regression coefficients determined by R script */

double intercept = 0.700428288;
double m1= 0.003964245;
double m2= 0.378501807;


/* main function */

int main()

{


/* Declare the arrays */

string rows[1000];
int num_bedrooms[1000]; 
int fields[9]; 

/* Read in the test data */

ifstream File("test.csv");

  if(!File){
  	
    return -1;}  
    
       getline(File,header);
       
         while(!File.eof()){
         	
              getline(File,line);
              
                 if(line!=""){
                 	
                    rows[n]=line;n++;}}
File.close();


/* Now extract the two main variables */


for(i=0;i<n;i++){
	
  index=0; j=0; pos=0;
  
    while(pos>-1){
    	
      pos=rows[i].find(",",index);
      
         if(pos!=string::npos){
         	
            fields[j]=pos;j++;index=pos+1;}}
 
            
/* Convert floor_area and number of rooms from strings to integers */


floor_area=atoi(rows[i].substr(fields[1]+1,(fields[2]-(fields[1]+1))).c_str());

num_rooms=atoi(rows[i].substr(fields[2]+1,(fields[3]-(fields[2]+1))).c_str());


/* Determine rounding-up factor based on the number of rooms */


double rounding_factor= sqrt(num_rooms)/10.0;


/* Determine the predicted number of bedrooms */


num_bedrooms[i] = (int) (intercept + (floor_area * m1 ) +  (num_rooms * m2 ) + rounding_factor);


/* end for loop */

}


/* Print out the forecast */

ofstream Results("prediction.csv");
Results<<header<<"Predicted_Bedrooms"<<endl;
for(i=0;i<n;i++){
Results<<rows[i]<<num_bedrooms[i]<<endl;}
Results.close();


/* Print message to user */

cout<<"Please check the file 'prediction.csv' for results"<<endl<<endl;


/* end main function */

system("PAUSE");
return 0;
}  


